package com.library.webtechmidterm24810;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebtechMidterm24810Application {

	public static void main(String[] args) {
		SpringApplication.run(WebtechMidterm24810Application.class, args);
	}

}
