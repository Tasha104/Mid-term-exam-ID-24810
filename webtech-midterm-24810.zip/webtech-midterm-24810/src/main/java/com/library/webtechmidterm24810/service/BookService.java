package com.library.webtechmidterm24810.service;

import com.library.webtechmidterm24810.model.Book;
import com.library.webtechmidterm24810.repository.BookRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.UUID;

@Service
public class BookService {
    private final BookRepository bookRepository;
    private final String UPLOAD_DIR = "uploads/covers/";

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
        // Create upload directory if it doesn't exist
        try {
            Files.createDirectories(Paths.get(UPLOAD_DIR));
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload directory!", e);
        }
    }

    public Page<Book> findAllBooks(Pageable pageable) {
        return bookRepository.findAll(pageable);
    }

    public Page<Book> searchBooks(String query, String searchType, Pageable pageable) {
        switch (searchType.toLowerCase()) {
            case "title":
                return bookRepository.findByTitleContainingIgnoreCase(query, pageable);
            case "author":
                return bookRepository.findByAuthorContainingIgnoreCase(query, pageable);
            case "isbn":
                return bookRepository.findByIsbnContaining(query, pageable);
            default:
                return bookRepository.findAll(pageable);
        }
    }

    public Optional<Book> findById(Long id) {
        return bookRepository.findById(id);
    }

    public Book saveBook(Book book, MultipartFile coverImage) {
        if (coverImage != null && !coverImage.isEmpty()) {
            String fileName = UUID.randomUUID().toString() + "_" + coverImage.getOriginalFilename();
            try {
                Path path = Paths.get(UPLOAD_DIR + fileName);
                Files.write(path, coverImage.getBytes());
                book.setCoverImage(fileName);
            } catch (IOException e) {
                throw new RuntimeException("Failed to store file " + fileName, e);
            }
        }
        return bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        // Delete cover image if exists
        if (book.getCoverImage() != null) {
            try {
                Files.deleteIfExists(Paths.get(UPLOAD_DIR + book.getCoverImage()));
            } catch (IOException e) {
                // Log the error but continue with book deletion
                e.printStackTrace();
            }
        }

        bookRepository.deleteById(id);
    }

    public Book updateBook(Long id, Book bookDetails, MultipartFile coverImage) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setIsbn(bookDetails.getIsbn());
        book.setDescription(bookDetails.getDescription());
        book.setPublishYear(bookDetails.getPublishYear());
        book.setPublisher(bookDetails.getPublisher());
        book.setCopies(bookDetails.getCopies());
        book.setAvailableCopies(bookDetails.getAvailableCopies());

        return saveBook(book, coverImage);
    }
}