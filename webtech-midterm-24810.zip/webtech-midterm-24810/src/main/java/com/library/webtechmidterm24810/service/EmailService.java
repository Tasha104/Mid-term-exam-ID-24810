package com.library.webtechmidterm24810.service;

public class EmailService {
}
