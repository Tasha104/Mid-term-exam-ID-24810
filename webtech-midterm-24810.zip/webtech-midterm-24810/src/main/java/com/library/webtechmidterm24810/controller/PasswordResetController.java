package com.library.webtechmidterm24810.controller;

import com.library.webtechmidterm24810.model.User;
import com.library.webtechmidterm24810.service.PasswordResetService;
import com.library.webtechmidterm24810.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PasswordResetController {
    private final UserService userService;
    private final PasswordResetService passwordResetService;

    public PasswordResetController(UserService userService, PasswordResetService passwordResetService) {
        this.userService = userService;
        this.passwordResetService = passwordResetService;
    }

    @GetMapping("/forgot-password")
    public String processForgotPasswordForm(Model model) {
        model.addAttribute("user", new User());
        return "auth/forgot-password";
    }

    @PostMapping("/forgot-password")
    public String processForgotPassword(@RequestParam("email") String email, Model model) {
        User user = userService.findByEmail(email);
        if (user == null) {
            model.addAttribute("error", "Email not found");
        } else {
            passwordResetService.createPasswordResetTokenForUser(user);
            model.addAttribute("message", "Reset password link has been sent to your email");
        }
        return "auth/forgot-password";
    }

    @GetMapping("/reset-password")
    public String showResetPasswordForm(@RequestParam("token") String token, Model model) {
        String result = passwordResetService.validatePasswordResetToken(token);
        if (!"valid".equals(result)) {
            model.addAttribute("error", "Invalid or expired token");
            return "auth/forgot-password";
        }
        model.addAttribute("token", token);
        return "auth/reset-password";
    }

    @PostMapping("/reset-password")
    public String handlePasswordReset(@RequestParam("token") String token,
                                      @RequestParam("password") String password,
                                      Model model) {
        String result = passwordResetService.validatePasswordResetToken(token);
        if (!"valid".equals(result)) {
            model.addAttribute("error", "Invalid or expired token");
            return "auth/forgot-password";
        }

        User user = userService.findUserByPasswordResetToken(token);
        passwordResetService.changeUserPassword(user, password);
        model.addAttribute("message", "Password has been reset successfully");
        return "redirect:/login?resetSuccess";
    }
}