package com.library.webtechmidterm24810.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

public class HomeController {
    @GetMapping("/")
    public String HomePage(HttpSession session, Model model) {
        // Retrieve session attributes
        String role = (String) session.getAttribute("role");
        String username = (String) session.getAttribute("username");

        // Add them to the model
        model.addAttribute("role", role);
        model.addAttribute("username", username);
        return "/index";
    }
}
