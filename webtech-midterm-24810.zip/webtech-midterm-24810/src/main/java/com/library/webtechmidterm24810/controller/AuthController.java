package com.library.webtechmidterm24810.controller;

import com.library.webtechmidterm24810.model.User;
import com.library.webtechmidterm24810.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String loginForm(Model model) {
        model.addAttribute("user", new User());
        return "auth/login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("user") User user, Model model, HttpServletRequest request) {
        User userData = userService.findByEmail(user.getEmail());
        if (user.getPassword().matches(userData.getPassword())) {
            HttpSession session = request.getSession();
            session.setAttribute("role", user.getRoles().toString());
            session.setAttribute("username", user.getUsername());
            System.out.println(user.getRoles().toString());
            System.out.println(user.getUsername());
            return "redirect:/";
        } else {
            model.addAttribute("error", "Username or email is incorrect");
            return "auth/login";
        }
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "auth/register";
    }

    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute("user") User user,
                               BindingResult result,
                               Model model) {
        if (result.hasErrors()) {
            return "auth/register";
        }

        try {
            userService.registerNewUser(user);
            return "redirect:/login?registered";
        } catch (Exception e) {
            model.addAttribute("error", "Username or email already exists");
            return "auth/register";
        }
    }
}