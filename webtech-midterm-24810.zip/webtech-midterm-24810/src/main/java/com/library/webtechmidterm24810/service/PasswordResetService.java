package com.library.webtechmidterm24810.service;

import com.library.webtechmidterm24810.model.PasswordResetToken;
import com.library.webtechmidterm24810.model.User;
import com.library.webtechmidterm24810.repository.PasswordResetTokenRepository;
import com.library.webtechmidterm24810.repository.UserRepository;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class PasswordResetService {
    private final UserRepository userRepository;
    private final PasswordResetTokenRepository tokenRepository;
    private final JavaMailSender mailSender;

    public PasswordResetService(
            UserRepository userRepository,
            PasswordResetTokenRepository tokenRepository,
            JavaMailSender mailSender) {
        this.userRepository = userRepository;
        this.tokenRepository = tokenRepository;
        this.mailSender = mailSender;
    }

    public void createPasswordResetTokenForUser(User user) {
        String token = UUID.randomUUID().toString();
        PasswordResetToken myToken = new PasswordResetToken();
        myToken.setUser(user);
        myToken.setToken(token);
        myToken.setExpiryDate(LocalDateTime.now().plusHours(24));
        tokenRepository.save(myToken);

        // Send email
        SimpleMailMessage mail = new SimpleMailMessage();
        mail.setTo(user.getEmail());
        mail.setSubject("Password Reset Request");
        mail.setText("To reset your password, click the link below:\n" +
                "http://localhost:8080/reset-password?token=" + token);
        mailSender.send(mail);
    }

    public String validatePasswordResetToken(String token) {
        PasswordResetToken passToken = tokenRepository.findByToken(token);
        if (passToken == null) {
            return "invalidToken";
        }

        if (passToken.isExpired()) {
            tokenRepository.delete(passToken);
            return "expired";
        }

        return "valid";
    }

    public void changeUserPassword(User user, String newPassword) {
        user.setPassword(newPassword);
        userRepository.save(user);
    }
}