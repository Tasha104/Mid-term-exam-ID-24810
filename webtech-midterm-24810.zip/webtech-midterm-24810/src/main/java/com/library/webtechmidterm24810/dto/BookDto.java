package com.library.webtechmidterm24810.dto;

public class BookDto {
}
