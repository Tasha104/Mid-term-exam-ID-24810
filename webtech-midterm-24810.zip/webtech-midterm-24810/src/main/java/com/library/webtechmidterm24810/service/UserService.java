package com.library.webtechmidterm24810.service;

import com.library.webtechmidterm24810.dto.UserRegistrationDto;
import com.library.webtechmidterm24810.model.PasswordResetToken;
import com.library.webtechmidterm24810.model.Role;
import com.library.webtechmidterm24810.model.User;
import com.library.webtechmidterm24810.repository.PasswordResetTokenRepository;
import com.library.webtechmidterm24810.repository.RoleRepository;
import com.library.webtechmidterm24810.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@Transactional
public class UserService {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordResetTokenRepository passwordResetTokenRepository;

    public UserService(UserRepository userRepository,
                       RoleRepository roleRepository,
                       PasswordResetTokenRepository passwordResetTokenRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordResetTokenRepository = passwordResetTokenRepository;
    }

    public void registerNewUser(User user) {
        // Check if username or email already exists
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists");
        }
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        // Encode password
        user.setPassword(user.getPassword());

        // Set default role as USER
        Role userRole = roleRepository.findByName("USER")
                .orElseThrow(() -> new RuntimeException("Default role not found"));
        Set<Role> roles = new HashSet<>();
        roles.add(userRole);
        user.setRoles(roles);

        userRepository.save(user);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username).orElseThrow();
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }

    public User findUserByPasswordResetToken(String token) {
        PasswordResetToken resetToken = passwordResetTokenRepository.findByToken(token);
        if (resetToken != null) {
            return resetToken.getUser();
        }
        throw new RuntimeException("Invalid password reset token");
    }

    public void updatePassword(User user, String newPassword) {
        user.setPassword(newPassword);
        userRepository.save(user);
    }

    public boolean validateCurrentPassword(User user, String currentPassword) {
        return currentPassword.matches(user.getPassword());
    }

    public void initiatePasswordReset(String email) {
        User user = findByEmail(email);
        if (user != null) {
            // Remove any existing token
            Optional<PasswordResetToken> existingToken = passwordResetTokenRepository.findByUser(user);
            existingToken.ifPresent(passwordResetTokenRepository::delete);

            // Create new token
            PasswordResetToken token = new PasswordResetToken();
            token.setUser(user);
            token.setToken(generateToken());
            passwordResetTokenRepository.save(token);

            // Send email with token
            // Note: Email sending implementation would be handled by EmailService
        }
    }

    private String generateToken() {
        return java.util.UUID.randomUUID().toString();
    }

    public void updateUser(User user) {
        userRepository.save(user);
    }

    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }

    public boolean usernameExists(String username) {
        return userRepository.existsByUsername(username);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }

    // Method to add role to user
    public void addRoleToUser(String username, String roleName) {
        User user = findByUsername(username);
        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new RuntimeException("Role not found"));
        user.getRoles().add(role);
        userRepository.save(user);
    }

    // Method to remove role from user
    public void removeRoleFromUser(String username, String roleName) {
        User user = findByUsername(username);
        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new RuntimeException("Role not found"));
        user.getRoles().remove(role);
        userRepository.save(user);
    }

    // Method to update user profile
    public User updateProfile(Long userId, UserRegistrationDto userDto) {
        User user = getUserById(userId);

        // Update only if email is changed and new email doesn't exist
        if (!user.getEmail().equals(userDto.getEmail()) && !emailExists(userDto.getEmail())) {
            user.setEmail(userDto.getEmail());
        }

        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());

        return userRepository.save(user);
    }

    // Method to change user password
    public void changePassword(Long userId, String oldPassword, String newPassword) {
        User user = getUserById(userId);

        if (!oldPassword.matches(user.getPassword())) {
            throw new RuntimeException("Current password is incorrect");
        }

        user.setPassword(newPassword);
        userRepository.save(user);
    }

    // Method to get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}