package com.library.webtechmidterm24810.service;

import com.library.webtechmidterm24810.model.Book;
import com.library.webtechmidterm24810.repository.BookRepository;
import com.library.webtechmidterm24810.repository.UserRepository;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DashboardService {
    private final BookRepository bookRepository;
    private final UserRepository userRepository;

    public DashboardService(BookRepository bookRepository, UserRepository userRepository) {
        this.bookRepository = bookRepository;
        this.userRepository = userRepository;
    }

    @Data
    public static class DashboardStats {
        private long totalBooks;
        private long totalUsers;
        private long availableBooks;
        private long borrowedBooks;
        private Map<String, Long> booksByGenre;
        private Map<Integer, Long> booksByYear;
    }

    public DashboardStats getDashboardStats() {
        DashboardStats stats = new DashboardStats();

        stats.setTotalBooks(bookRepository.count());
        stats.setTotalUsers(userRepository.count());

        // Calculate available and borrowed books
        long availableBooks = bookRepository.findAll().stream()
                .mapToLong(Book::getAvailableCopies)
                .sum();
        long totalCopies = bookRepository.findAll().stream()
                .mapToLong(Book::getCopies)
                .sum();

        stats.setAvailableBooks(availableBooks);
        stats.setBooksByGenre(calculateBooksByGenre());
        stats.setBooksByYear(calculateBooksByYear());
        stats.setBorrowedBooks(totalCopies - availableBooks);

        return stats;
    }

    private Map<String, Long> calculateBooksByGenre() {
        // This is a placeholder - you would need to add a genre field to the Book entity
        return new HashMap<>();
    }

    private Map<Integer, Long> calculateBooksByYear() {
        Map<Integer, Long> booksByYear = new HashMap<>();
        bookRepository.findAll().forEach(book -> {
            if (book.getPublishYear() != null) {
                booksByYear.merge(book.getPublishYear(), 1L, Long::sum);
            }
        });
        return booksByYear;
    }
}
