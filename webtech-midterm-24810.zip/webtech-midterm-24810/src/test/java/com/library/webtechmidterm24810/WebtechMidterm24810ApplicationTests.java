package com.library.webtechmidterm24810;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebtechMidterm24810ApplicationTests {

	@Test
	void contextLoads() {
	}

}
